const Settings = require("../models/Settings");

const SETTINGS_KEY = "maintenance";

// The gate runs on every API request, so keep a very short in-memory cache
// instead of hitting Mongo each time. The settings controller clears it the
// moment staff change maintenance, so toggles still apply instantly. The
// time window is re-evaluated on every request, so start/end times are exact.
const CACHE_TTL_MS = 3000;
let cache = { doc: null, at: 0 };

function invalidateMaintenanceCache() {
  cache = { doc: null, at: 0 };
}

async function loadSettings() {
  if (cache.at && Date.now() - cache.at < CACHE_TTL_MS) return cache.doc;

  const doc = await Settings.findOne({ key: SETTINGS_KEY }).lean();
  cache = { doc, at: Date.now() };

  return doc;
}

// Always reachable, maintenance or not — health checks, the maintenance
// status itself, and the auth endpoints an admin/manager needs to sign in
// and sign out.
const ALWAYS_ALLOWED = new Set([
  "/api/health",
  "/api/settings/maintenance",
  "/api/auth/login",
  "/api/auth/me",
  "/api/auth/logout",
]);

function isActive(m) {
  if (!m?.enabled) return false;

  const now = Date.now();

  if (m.startTime && now < new Date(m.startTime).getTime()) return false;
  if (m.endTime && now >= new Date(m.endTime).getTime()) return false;

  return true;
}

/**
 * Blocks ALL API traffic (customers, managers and admins alike) while
 * maintenance mode is on. Only ALWAYS_ALLOWED routes stay open: health,
 * the maintenance status/toggle (the toggle itself still requires an
 * admin/manager token) and login/logout, so staff can sign in and switch
 * maintenance off. A check failure never takes the whole site down — it
 * just falls through and lets the request proceed.
 */
async function maintenanceGate(req, res, next) {
  try {
    if (ALWAYS_ALLOWED.has(req.path)) return next();

    const doc = await loadSettings();

    if (!isActive(doc?.maintenance)) return next();

    res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");

    return res.status(503).json({
      success: false,
      message:
        doc.maintenance.message ||
        "Orbit Buy is undergoing scheduled maintenance. Please check back soon.",
      maintenance: {
        active: true,
        startTime: doc.maintenance.startTime || null,
        endTime: doc.maintenance.endTime || null,
      },
    });
  } catch (error) {
    next();
  }
}

module.exports = maintenanceGate;
module.exports.invalidateMaintenanceCache = invalidateMaintenanceCache;